<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "empresa";

try{
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	// set the PDD error mode to exception
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "INSERT INTO persona(Identificacion, nombre, apellido, direccion) VALUES ('".$_POST['ID']."','".$_POST['NAME']."','".$_POST['APEL']."','".$_POST['DIREC']."')";

	$conn->exec($sql);
	echo "Registro Existoso";

	}
	catch(PDOException $e)
	{
		echo "ERROR AL INGRENSAR LOS DATOS - ERROR: ";
		echo $sql."<br>" .$e->getMessage();
	}

	$conn=null;
?>

